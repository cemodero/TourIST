package com.example.demo;

public class DestinationException extends RuntimeException {


	public DestinationException() {
		super();
	}
	
	public DestinationException(String message) {
		super(message);
	}
}

package com.example.demo;

public class ItineraryException extends RuntimeException {

	public ItineraryException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ItineraryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
